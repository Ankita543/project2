package utility;

public class Config {
    public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/testengine";
    public static final String DB_USER = "root";
    public static final String DB_PASS = "qwert";
}
