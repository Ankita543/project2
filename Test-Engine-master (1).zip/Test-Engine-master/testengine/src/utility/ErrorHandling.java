package utility;

public class ErrorHandling {
    public static void displayStackTrace(Exception ex){
        ex.printStackTrace();
    }
}

